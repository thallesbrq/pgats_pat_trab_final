const calcularTotal = (ferramentas, comprar) => {
    const quantidadeDeFerramentas = ferramentas.length 
    const quantidadeComprar = comprar.length 
    const ferramentasEncontradas = [];
    let total = 0;

    if (quantidadeDeFerramentas === 0 || quantidadeComprar === 0) {
      throw new Error("Ambas as listas precisam ter ao menos um item.");
    }
  
    for (let i = 0; i < quantidadeComprar; i++) {
      let ferramentaComprar = comprar[i];
      let ferramentaEncontrada;
      
      for (let k = 0; k < quantidadeDeFerramentas; k++ ) {
        let ferramenta = ferramentas[k]

        if(ferramenta.nome === ferramentaComprar){
          ferramentaEncontrada = ferramenta
          break
        }
      }

      if (!ferramentaEncontrada) {
        throw new Error("Nenhuma ferramenta desejada encontrada.");
      }
      
      total = total + ferramentaEncontrada.preco;
      
      ferramentasEncontradas.push(ferramentaEncontrada.nome);
    }
  
    return `O valor a pagar pelas ferramentas (${ferramentasEncontradas.join(", ")}) é R$ ${total.toFixed(2)}`;
  }
  
  module.exports = { calcularTotal };