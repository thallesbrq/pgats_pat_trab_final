Problema:

Os usuários do sistema de compras tem uma lista onde podem ver nomes de ferramentas de automação de testes disponíveis para compra, essa lista contém seu nome, preço e o fabricante. Eles podem ter também uma lista com nomes das ferramentas que gostariam de comprar. 

Missão:

- Receber a lista de ferramentas disponíveis para a compra e a lista de ferramentas que deseja comprar

- Calcular o total a ser pago pelas ferramentas que deseja comprar retornando a mensagem "O valor a pagar pelas ferramentas (Nome da Ferramenta, Nome da Ferramenta, Nome da Ferramenta) é R$ 999.99". A função e mensagem retornada devem ser capazes de lidar com quantas ferramentas forem passadas como parâmetro.

- Se a lista de ferramentas disponíveis ou a lista de ferramentas para comprar estiverem vazias, um erro com a mensagem "Ambas as listas precisam ter ao menos um item." deve ser exibido.

- Se as ferramentas a comprar não forem encontradas na lista de ferramentas a venda, um erro com a mensagem "Nenhuma ferramenta desejada encontrada." deverá ser exibido.

- Crie e exporte a função calcularTotal, ela deve ter dois parâmetros: ferramentas, comprar

Sua tarefa é escrever a função que esses testes estão testando. 

Quando todos passarem e sua função estiver escrita obedecendo o problema estipulado, você conseguiu concluir sua atividade. 

Exemplo de uso da função:

const ferramentas = [
   { nome: "UFT", preco: 100, fabricante: "OpenText" },
   { nome: "TestComplete", preco: 200, fabricante: "Smartbear" },
   { nome: "TOSCA", preco: 300, fabricante: "Tricents" }
];

const comprar = [ "UFT", "TOSCA" ];

const resultado = calcularTotal(ferramentas, comprar);

ATENÇÃO: A função deve, obrigatóriamente, ter esse nome e esses dois parâmetros sendo ferramentas com uma lista de objetos e comprar uma lista de strings.

Instruções:

- Crie uma nova pasta em seu computador onde será armazenado o projeto ok
- Comece o projeto com o comando npm init ok
- Instale o mocha usando o comando npm install -D mocha ok
- Configure o arquivo packages.js conforme aprendemos em aula para que o comando npm test possa executar os testes com mocha ok
- Crie a pasta test e a pasta src dentro da raiz do projeto ok 
- Crie uma pasta chamada compras em ambas as pastas ok
- Crie um arquivo chamado compras.js dentro da pasta src/compras ok
- Crie e exporte a função calcularTotal, ela deve ter dois parâmetros: ferramentas, comprar
- Crie um arquivo chamado compras.test.js dentro da pasta test/compras ok
- Copie os testes contidos no gist acima e cole dentro do arquivo compras.test.js ok

Atividade:

Crie a função mencionada no problema acima e escreva dentro dela a programação necessária para fazer o teste calculo.test.js passarem. 

Sua tarefa é escrever a função que esses testes estão testando. 

Quando todos passarem e sua função estiver escrita obedecendo o problema estipulado, você conseguiu concluir sua atividade. 

Exemplo de uso da função:

const ferramentas = [
   { nome: "UFT", preco: 100, fabricante: "OpenText" },
   { nome: "TestComplete", preco: 200, fabricante: "Smartbear" },
   { nome: "TOSCA", preco: 300, fabricante: "Tricents" }
];

const comprar = [ "UFT", "TOSCA" ];

const resultado = calcularTotal(ferramentas, comprar);

ATENÇÃO: A função deve, obrigatóriamente, ter esse nome e esses dois parâmetros sendo ferramentas com uma lista de objetos e comprar uma lista de strings.

Dicas:

- Comece fazendo os testes passarem, depois disso, melhore o código para ficar mais bonito e organizado;
- Sua função não devetá ter console.log e nem comentários desnecessários, isso tirará pontos;
- Aprendemos na aula como apresentar mensagens de erro usando Exceções, retorne a esse ponto da aula se necessário.


Pensamento Computacional 

Decomposição 

1.  Validar as Listas: Verificar se as duas listas fornecidas (ferramentas disponíveis para  Compra e ferramentas desejadas) possuem pelo menos um item cada.

2.  Comparar Listas: Checar quais ferramentas desejadas estão presentes na lista de ferramentas disponíveis.

3.  Calcular o Preço Total: Somar o preço das ferramentas desejadas que estão disponíveis.

4.  Gerar Mensagem: Formatar e retornar a mensagem com os nomes das ferramentas que serão compradas e o preço total a ser pago.

-----

tarefas 

// Verificar se as listas estão vazias
// Percorrer a lista de ferramentas a comprar
// Encontrar ferramenta na lista de ferramentas disponíveis
// Se nenhuma ferramenta for encontrada, lançar uma exceção
// Adicionar preço ao total e nome da ferramenta à lista de encontradas
// Retornar mensagem com o total a pagar